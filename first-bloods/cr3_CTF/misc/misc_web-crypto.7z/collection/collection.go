package collection

var Secrets = map[string]string{
	"fanfic":                      "REDACTED",
	"very-secret-totaly-not-flag": "REDACTED",
	"secret":                      "REDACTED",
	"gnu-linux":                   "REDACTED",
	"recipe":                      "REDACTED",
	"flag":                        "REDACTED",
}